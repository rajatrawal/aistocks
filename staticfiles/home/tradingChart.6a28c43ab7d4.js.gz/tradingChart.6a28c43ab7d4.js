

  new TradingView.widget(
  {
  "autosize": true,
  "symbol": `${tradingViewExchangeName}:${tradingViewSymbolName}`,
  "interval": "D",
  "timezone": "Etc/UTC",
  "theme": "light",
  "style": "1",
  "locale": "en",
  "toolbar_bg": "#f1f3f6",
  "enable_publishing": false,
  "save_image": false,
  "container_id": "tradingview_0ebba"
}
  );
